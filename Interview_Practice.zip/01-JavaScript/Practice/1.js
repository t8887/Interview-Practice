

// function increment(){
//     let initValue = 0;
//     return () => {
//         initValue = ++initValue
//         return initValue
//     }   

// }

// const intr = increment(10)
// console.log(intr());
// console.log(intr());
// console.log(intr());
// console.log(intr());
// console.log(intr());



// for (var i = 0; i < 3; i++) {
//     setTimeout(() => console.log(i), 100);
// }

// for (let i = 0; i < 3; i++) {
//     setTimeout(() => console.log(i), 100); 
// }


// for (var i = 0; i < 3; i++) {
//     ((j) => {
//         setTimeout(() => console.log(j), 100); 
//     })(i);
// }